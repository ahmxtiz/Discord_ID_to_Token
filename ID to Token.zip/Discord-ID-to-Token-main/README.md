# Discord-ID to Token

**This Discord tool allows you to get the first part of someone's token trought his ID.**

![Token](https://user-images.githubusercontent.com/81310818/112335524-9b2ba080-8cbc-11eb-9a35-7aca52589c75.PNG)
> **qwe**
